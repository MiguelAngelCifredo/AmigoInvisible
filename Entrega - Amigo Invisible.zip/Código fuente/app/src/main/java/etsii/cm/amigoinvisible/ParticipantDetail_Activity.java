package etsii.cm.amigoinvisible;

public class ParticipantDetail_Activity {
}
